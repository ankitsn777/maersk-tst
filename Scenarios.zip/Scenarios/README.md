# APMM
Based on the three scenario based problems given

This repo provides detailed solution statements and Explanationas well as screenshots of the various Azure Devops configuration associated to the problems whereever applicable.
Each solution to the scenarios is inside folders named as scenario1,scenario2,scenario3. Also other artifacts such as ARM template can be found in separate folder inside the corresponding scenario directory.
